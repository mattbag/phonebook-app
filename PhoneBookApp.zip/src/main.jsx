var React = require('react');
var ReactDOM = require('react-dom');

var ContactList = require('./components/ContactList.jsx');

ReactDOM.render(<ContactList />, document.getElementById('app'));
