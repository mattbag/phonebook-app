var contactsDB = [
{ 'id':1, 'name': 'Mitch','mobile':'+5437885', 'address':'test 1','picture':'http://stevensegallery.com/300/300'},
{ 'id':2, 'name': 'Nico','mobile':'+54345325', 'address':'test 2','picture':'http://fillmurray.com/200/200'},
{ 'id':3, 'name': 'Laura','mobile':'+543678875', 'address':'test 3','picture':'http://placecage.com/200/200'},
{ 'id':4, 'name': 'Freya','mobile':'+54356765', 'address':'test 5','picture':'http://fillmurray.com/300/300'}

];
module.exports = contactsDB;